// TypeScript file
class GameManager {
    public static stage:egret.Stage;
}