declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class GameOverPanelSkin extends eui.Skin{
}
declare class returnHallButton extends eui.Skin{
}
declare class ListButtonSkin extends eui.Skin{
}
declare class WelcomePanelSkin extends eui.Skin{
}
declare class buttomList extends eui.Skin{
}
declare class buttomList2 extends eui.Skin{
}
declare class nameAreaLeftBtn extends eui.Skin{
}
declare class nameAreaRightBtn extends eui.Skin{
}
declare class nameBtn extends eui.Skin{
}
declare class selectAreaBtn2 extends eui.Skin{
}
declare class selectAreaBtn3 extends eui.Skin{
}
declare class startBtn extends eui.Skin{
}
declare class topList extends eui.Skin{
}
declare class topList2 extends eui.Skin{
}
